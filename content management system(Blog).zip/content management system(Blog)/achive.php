<!Doctype html>
<html>
<head>
  <meta charset="UTF-8">
   <meta name="Author" content="prasaath">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
 <link rel="stylesheet" href="css/fontawesome.min.css" type="text/css">
 <link rel="stylesheet" href="css/style.css" type="text/css">

</head>
<body background="img/bg.jpg">
<div class="container"  style="background:white"> 
<header class="navbar navbar-inverse navbar-fixed-top" style="background-color:black">
  <div class="container">
        <a class="navbar-brand  navbar-fixed-left" href="#" style="cursor: pointer"> Infiniti Software Solutions </a>
		<ul class="nav navbar-header">
      <li class="active">  <a href="index.php">&nbsp Home </a> </li>
          <li><a href="about.php">&nbsp About</a></li>
     <li><a href="contacts.php ">&nbsp Contacts </a></li>
    </ul>
	</div>
    </header>
    <div class="row">
	 <div class="col-md-8">
	 <h2 class="heading"> Infiniti Marketting Group </h2>
	 
	 </div>
	 </div>
	 <br>
	 <div class="container"  style="background:white"> 
<nav class="navbar navbar-inverse " style="background-color:black">
  <div class="container-fluid">
       	<ul class="nav navbar-header  ">
      <li class="active"><a href="travel.php">&nbsp Travel Updates</a></li>
          <li><a href="product.php">&nbsp Product
updates</a></li>
     <li><a href="tech.php "> &nbsp Technology updates</a></li>
     <li><a href="events.php "> &nbsp Events</a></li>
     <li><a href="achive.php ">&nbsp Achievements</a></li>
     <li><a href="awards.php ">&nbsp Awards</a></li>
     <li><a href="testi.php ">&nbsp Testimonial</a></li>
    </ul>
	</div>
	</nav>
	</div>
	<div class="row">
	 <div class="col-md-8">
	<br>
 <div class="col-md-4"> 
	 <div class="line1">
	  <div class="left">
	   <span> Achievements  </span>
	  </div>
	  </div>
	  </div>
	<div class="post">
	<div class="row">
	<div class="col-md-4" style="border:0px solid">  
	<img src="img/trav.jpg" class="img img-thumbnail" >
	</div>
	<div class="col-md-8">
   <h5 style="font:weight: bold;color: #333"> News </h5>
   <h6 style="float:right;"> Date : 25/06/2019 </h6>
   <br>
    <p style="text-align:justify" > News-Breaking news, latest news, top videos, headlines, politics, sports
	</p>
	</div>
 </div>
 <div class="row">
	<div class="col-md-4" style="border:0px solid">  
	<img src="img/trav.jpg" class="img img-thumbnail" >
	</div>
	<div class="col-md-8">
   <h5 style="font:weight: bold;color: #333"> News </h5>
   <h6 style="float:right;"> Date : 25/06/2019 </h6>
   <br>
    <p style="text-align:justify" > News-Breaking news, latest news, top videos, headlines, politics, sports
	</p>
	</div>
 </div>
 <div class="row">
	<div class="col-md-4" style="border:0px solid">  
	<img src="img/trav.jpg" class="img img-thumbnail" >
	</div>
	<div class="col-md-8">
   <h5 style="font:weight: bold;color: #333"> News </h5>
   <h6 style="float:right;"> Date : 25/06/2019 </h6>
   <br>
    <p style="text-align:justify" > News-Breaking news, latest news, top videos, headlines, politics, sports
	</p>
	</div>
 </div>
  </div>
  
	 </div>
	
	<?php include("include/side.php");
	?>
</div>
	
	<div class="footer">
  <p>Copyright @ 2019 prasaath</p>
</div>
</div>
</div>
</body>
</html>