<?php
$con=mysqli_connect("localhost","root","8056756256","news");

 


?>