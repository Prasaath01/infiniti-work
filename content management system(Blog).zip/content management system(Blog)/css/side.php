	<div class="col-md-4"> 
	 <div class="line">
	  <div class="right">
	   <span>  Latest Post  </span>
	  </div>
	  </div>
<br>
	  	  <div class="row">
	
	<div class=col-md-4> <img class="rounded" src="img/travel2.jpg" style="width: 100px;
	height: 80px padding: 5px;" > 
	</div>
	<div class=col-md-8> <br> <span class="side_post"><a href=#> Latest News </a> </span> </div>
	</div>
	<br>

 	  <div class="row">
	
	<div class=col-md-4> <img class="rounded" src="img/travel2.jpg" style="width: 100px;
	height: 80px padding: 5px;" > 
	</div>
	<div class=col-md-8> <br> <span class="side_post"><a href=#> Coming up</a> </span> </div>
	</div>
 <br>
 	 <div class="line">
	  <div class="right">
	   <span> Categories </span>
	  </div>
	  </div>
	  <div class="cat">
	  <a href="#"> Technology </a>
	  <a href="#"> Travels </a>
	  <a href="#"> Events </a>
	 	 </div> 
	
</div>